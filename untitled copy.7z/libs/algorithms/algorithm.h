//
// Created by User2 on 03.02.2024.
//

#ifndef UNTITLED_ALGORITHM_H
#define UNTITLED_ALGORITHM_H

#endif //UNTITLED_ALGORITHM_H
